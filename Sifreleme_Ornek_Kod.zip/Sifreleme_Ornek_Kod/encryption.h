#ifndef ENCRYPTION_H
#define ENCRYPTION_H

#include <iostream>
#include <string>

using namespace std;

class encryption {

public:

    encryption();

    //string mesaj="bu bir mesajdir.";
    string mesaj{"bu bir mesajdir."};

    void mesaj_al();

    void mesaj_yazdir();

    void sifreli_yazdir();

    encryption operator ^ (char);
    encryption operator ^= (char);

};

#endif // ENCRYPTION_H
