#include "encryption.h"

encryption::encryption()
{

}

void encryption::mesaj_al(){
    cout<<"Sifrelemek istediginiz mesaji giriniz : ";
    string tMesaj;
    getline(cin, tMesaj);
    this->mesaj = tMesaj;
    cout<<endl;
}

void encryption::mesaj_yazdir(){

    cout<<"Girdiginiz Mesaj ---> "<<this->mesaj<<endl<<endl;
}

void encryption::sifreli_yazdir(){
    cout<<"Sifreli Mesajiniz ---> "<<this->mesaj<<endl<<endl;
}

encryption encryption::operator^ (char key){
    for(unsigned int i = 0 ; i<this->mesaj.size(); i++){
        mesaj.at(i) = mesaj.at(i) ^ key;
    }
    return *this;
}

encryption encryption::operator^= (char key){
    for(uint i = 0 ; i<this->mesaj.size(); i++){
        mesaj.at(i) ^= key;
    }
    return *this;
}
