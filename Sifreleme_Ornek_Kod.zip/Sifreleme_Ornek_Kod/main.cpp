#include "encryption.h"

int main() {

    encryption Top_secret;

    Top_secret.mesaj_al();
    Top_secret.mesaj_yazdir();

    Top_secret ^='M';
    Top_secret.sifreli_yazdir();

    Top_secret ^='M';
    Top_secret.mesaj_yazdir();

    return 0;
}
