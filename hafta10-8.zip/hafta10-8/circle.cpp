#include "circle.h"
#include <iostream>

Circle::Circle(int xVal, int yVal, double rVal)
{
    x=xVal;
    y=yVal;
    setRadius(rVal);
}

void Circle::setRadius(double rVal){
    if(rVal>0)
        radius=rVal;
}

double Circle::getRadius() const{
    return radius;
}

double Circle::getDiameter() const{
    return 2*radius;
}

double Circle::getCircumference() const{
    return 3.14159 * getDiameter();
}

double Circle::getArea() const{
    return 3.14159 * radius * radius;
}

void Circle::print() const{
    std::cout << "Center = [" << x <<","<< y <<"]" << std::endl;
    std::cout << "Radius = " << radius <<std::endl;
}
