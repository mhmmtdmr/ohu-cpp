#include <iostream>
#include "circle.h"

using namespace std;

int main()
{
    Circle circle1(3, 4, 2.5);

    cout<<"X="<<circle1.getX()<<endl;
    cout<<"Y="<<circle1.getY()<<endl;
    cout<<"Radius="<<circle1.getRadius()<<endl;

    cout<<"-----------------------------------"<<endl;
    circle1.setX(10);
    circle1.setY(15);
    circle1.setRadius(3.5);

    circle1.print();
    cout<<"-----------------------------------"<<endl;
    cout<<"Area="<<circle1.getArea()<<endl;
    cout<<"Diameter="<<circle1.getDiameter()<<endl;
    cout<<"Circumference="<<circle1.getCircumference()<<endl;
    cout<<"-----------------------------------"<<endl;

    return 0;
}
