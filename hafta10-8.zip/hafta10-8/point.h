#ifndef POINT_H
#define POINT_H

class Point
{
public:
    Point(int xVal=0, int yVal=0);
    void setX(int);
    int getX() const;

    void setY(int);
    int getY() const;

    void print() const;
protected:
    int x,y;
};

#endif // POINT_H
