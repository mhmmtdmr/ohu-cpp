#include "point.h"
#include <iostream>

Point::Point(int xVal, int yVal)
{
    x=xVal;
    y=yVal;
}

void Point::setX(int xVal){
    x=xVal;
}

void Point::setY(int yVal){
    y=yVal;
}

int Point::getX() const{
    return x;
}

int Point::getY() const{
    return y;
}

void Point::print() const{
    std::cout<< "[" << x <<","<< y << "]"<< std::endl;
}
