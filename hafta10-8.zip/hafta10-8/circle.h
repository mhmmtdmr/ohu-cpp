#ifndef CIRCLE_H
#define CIRCLE_H
#include "point.h"

class Circle : public Point
{
public:
    Circle(int xVal=0, int yVal=0, double rVal=1);

    void setRadius(double);
    double getRadius() const;
    double getDiameter() const;
    double getCircumference() const;
    double getArea() const;

    void print() const;

protected:
    double radius;
};

#endif // CIRCLE_H
