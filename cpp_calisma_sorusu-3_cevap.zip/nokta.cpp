//
// Created by demir on 11/30/17.
//

#include "nokta.h"


nokta::nokta()
{
}

nokta::nokta(double x1, double y1, double z1) {
    this->x=x1;
    this->y=y1;
    this->z=z1;
}

void nokta::MysetX(double tmpX)
{
    x=tmpX;
}

void nokta::MysetY(double tmpY)
{
    y=tmpY;
}

void nokta::MysetZ(double tmpZ)
{
    z=tmpZ;
}

double nokta::MygetX()
{
    return this->x;
}

double nokta::MygetY()
{
    return this->y;
}

double nokta::MygetZ()
{
    return this->z;
}



