//
// Created by demir on 12/06/17.
//

#include "nokta.h"

//Normal Kurucu Fonksiyon
nokta::nokta () = default;

//Parametreli kurucu fonksiyon
nokta::nokta ( double x1 , double y1 , double z1 )
{
    this->x=x1;
    this->y=y1;
    this->z=z1;
}

//Nokta sınıfından olusturulan nesnenin x,y,z parametrelerini ayarlamaniza yarayan metodlar.
void nokta::MysetX(double tmpX)
{
    x=tmpX;
}

void nokta::MysetY(double tmpY)
{
    y=tmpY;
}

void nokta::MysetZ(double tmpZ)
{
    z=tmpZ;
}
//Nokta sınıfından olusturulan nesnenin x,y,z parametrelerini cagirmaniza yarayan metodlar.
double nokta::MygetX()
{
    return this->x;
}

double nokta::MygetY()
{
    return this->y;
}

double nokta::MygetZ()
{
    return this->z;
}

//Nokta sınıfından uretilen nesnenin siddetini bulan metod.
double nokta::siddet_bul()
{
    return sqrt( pow( MygetX() , 2 ) +
                 pow( MygetY() , 2 ) +
                 pow( MygetZ() , 2 )  );
}

//Nokta sınıfından uretilen nesnenin x,y,z parametrelerini kullanıcıdan alan metod
void nokta::vektor_gir()
{
    double x1{0} , y1{0} , z1{0};

    cout << "3 boyutlu bir vektor giriniz..." << endl;

    cin  >> x1
         >> y1
         >> z1;

    MysetX( x1 );
    MysetY( y1 );
    MysetZ( z1 );
}

//olusturulan nesnenin istenen yaricapta ki kurenin icinde olup olmadıgını kontrol eden metod.
void nokta::bul(double kure_yaricap)
{
    cout << "Girdiginiz Vektor, Yaricapi  = " << kure_yaricap <<" olan kureye gore konumu :-->\t";

    if ( siddet_bul() == kure_yaricap )
    {
        cout << "Kurenin uzerindedir." <<endl;
    }
    else if ( siddet_bul() > kure_yaricap  )
    {
        cout <<"Kurenin disindadir."   <<endl;
    }
    else
    {
        cout <<"Kurenin icindedir."    <<endl;
    }
}

//Olusturulan nesneyi ekrana yazdıran metod.
void nokta::vektor_yazdir()
{
    cout << "Girdiginiz Vektor = "  << "[ "  << MygetX() << " , "
                                             << MygetY() << " , "
                                             << MygetZ() << " ]\t:--> "
                                             << "Siddeti = "  << siddet_bul()  << endl;
}

