//
// Created by demir on 11/30/17.
//

#ifndef CPP_ODEV_NOKTA_H
#define CPP_ODEV_NOKTA_H

#include <cmath>
#include <iostream>
using namespace std;


class nokta {

private:

    double x,y,z;

public:

    //kurucu fonksiyon
    nokta();

    //parametreli kurucu fonksiyon
    nokta(double ,double,double);

    //x,y,z koordinatlarini ayarlamamizi saglayan fonksiyonlar
    void MysetX(double);
    void MysetY(double);
    void MysetZ(double);

    //x,y,z koordinatlarini alabilmemizi saglayan fonksiyonlar
    double MygetX();
    double MygetY();
    double MygetZ();

};



#endif //CPP_ODEV_NOKTA_H
