//
// Created by demir on 12/06/17.
//

#ifndef CPP_ODEV_NOKTA_H
#define CPP_ODEV_NOKTA_H

#include <iostream>
#include <cmath>

using namespace std;

class nokta {

private:
    //Nokta sinifinin private ozellikleri.
    double  x{ 0 },
            y{ 0 },
            z{ 0 };

public:

    //kurucu fonksiyon prototipi
    nokta();

    //parametreli kurucu fonksiyon prototipi
    nokta( double , double , double );

    //x,y,z koordinatlarini ayarlamamizi saglayan metotlarin prototipi
    void MysetX( double );
    void MysetY( double );
    void MysetZ( double );

    //x,y,z koordinatlarini alabilmemizi saglayan metotlarin prototipi
    double MygetX( );
    double MygetY( );
    double MygetZ( );

    //Nokta sınıfından uretilen nesnenin siddetini bulan metod.
    double siddet_bul( );

    //Nokta sınıfından uretilen nesnenin x,y,z parametrelerini kullanıcıdan alan metod
    void vektor_gir( );

    //olusturulan nesnenin istenen yaricapta ki kurenin icinde olup olmadıgını kontrol eden metod.
    void bul( double );

    //Olusturulan nesneyi ekrana yazdıran metod.
    void vektor_yazdir( );

};

#endif //CPP_ODEV_NOKTA_H
