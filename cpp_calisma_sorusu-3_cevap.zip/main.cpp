#include "nokta.h"

int main(){

    double kure_yaricap{5.0};

    nokta nokta1 ( 0 , 0 , 0 );

    nokta1.vektor_gir();

    nokta1.vektor_yazdir();

    //cout<<"Merkezi Orjin olan kurenin yaricapini giriniz."<<endl;
    //cin>>kure_yaricap;

    nokta1.bul(kure_yaricap);

    return 0;

}