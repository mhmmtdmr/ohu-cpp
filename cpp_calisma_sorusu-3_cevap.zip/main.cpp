#include "nokta.h"

//siddetlerin karsilastirmasini yapan fonksiyon
void bul( double referans_siddet, double siddet )
{
    if ( siddet == referans_siddet )
    {
        cout<<"Kurenin uzerindedir."<<endl;
    }
    else if ( siddet > referans_siddet )
    {
        cout<<"Kurenin disindadir."<<endl;
    }
    else
    {
        cout<<"Kurenin icindedir."<<endl;
    }
}

//kendisine verilen vektorun siidetini bulan fonskiyon
double siddet_bul(double x , double y , double z )
{
    return sqrt( pow( x , 2 ) +
                 pow( y , 2 ) +
                 pow( z , 2 ));
}

int main(){

    double x1,y1,z1;

    double referans_siddet{5.0};

    nokta nokta1 ( 0 , 0 , 0 );

    cout << "3 boyutlu bir vektor giriniz..." << endl;

    cin  >> x1
         >> y1
         >> z1;

    /*nokta1 nesnesinin x y z ozelliklerine
        sınıfın metodlarını kullanarakdeger ataması yaptık */
    nokta1.MysetX( x1 );
    nokta1.MysetY( y1 );
    nokta1.MysetZ( z1 );

    /*nokta1 nesnesinin x y z ozelliklerine erisen metodlari
        kullanarak siddet_bul fonskiyonuna x,y,z degerlerini atadik*/

    auto vector_siddeti = siddet_bul ( nokta1.MygetX() ,
                                       nokta1.MygetY() ,
                                       nokta1.MygetZ() );

    cout << "referans yaricap  = "  << referans_siddet << endl;

    cout << "vektorun siddeti  = "  << vector_siddeti  << endl;

    bul(referans_siddet, vector_siddeti);

    return 0;

}